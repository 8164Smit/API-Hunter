function Card({ meal, getRecipeVideo }) {
    return (
        <div className="card">
            <img src={meal.strMealThumb} alt={meal.strMeal} />

            <h3>{meal.strMeal}</h3>

            <button
                className="recipe-btn"
                onClick={() => getRecipeVideo(meal.idMeal)}
            >
                Watch Recipe
            </button>
        </div>
    );
}

export default Card;
