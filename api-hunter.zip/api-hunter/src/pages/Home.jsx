import { useEffect, useState } from "react";
import Search from "../components/Search";
import Card from "../components/Card";
import Loader from "../components/Loader";

function Home() {
    const [meals, setMeals] = useState([]);
    const [filteredMeals, setFilteredMeals] = useState([]);
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const fetchMeals = async () => {
        try {
            setLoading(true);
            setError("");

            const res = await fetch(
                "https://www.themealdb.com/api/json/v1/1/filter.php?c=Vegetarian"
            );

            const data = await res.json();

            if (data.meals === null) {
                setError("No vegetarian meals found");
                setMeals([]);
                setFilteredMeals([]);
            } else {
                setMeals(data.meals);
                setFilteredMeals(data.meals);
            }

            setLoading(false);
        } catch (err) {
            setError("Failed to fetch data");
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchMeals();
    }, []);

    const handleSearch = () => {
        if (search.trim() === "") {
            setFilteredMeals(meals);
            setError("");
            return;
        }

        const result = meals.filter((meal) =>
            meal.strMeal.toLowerCase().includes(search.toLowerCase())
        );

        if (result.length === 0) {
            setError("No matching meals found");
        } else {
            setError("");
        }

        setFilteredMeals(result);
    };

    const getRecipeVideo = async (id) => {
        try {
            const res = await fetch(
                `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`
            );

            const data = await res.json();

            if (data.meals && data.meals[0].strYoutube) {
                window.open(data.meals[0].strYoutube, "_blank");
            } else {
                alert("Video not available");
            }
        } catch (err) {
            alert("Failed to open video");
        }
    };

    return (
        <div className="container">
            <h1>API Hunter - Vegetarian Recipes</h1>

            <Search
                search={search}
                setSearch={setSearch}
                handleSearch={handleSearch}
            />

            {loading && <Loader />}

            {error && <p className="error">{error}</p>}

            <div className="grid">
                {filteredMeals.map((meal) => (
                    <Card
                        key={meal.idMeal}
                        meal={meal}
                        getRecipeVideo={getRecipeVideo}
                    />
                ))}
            </div>
        </div>
    );
}

export default Home;
